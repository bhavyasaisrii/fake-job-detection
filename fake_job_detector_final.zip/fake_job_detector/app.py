"""
app.py  –  Fake Job & Internship Detector
Flask backend with ML prediction pipeline.
"""

import os
import re
import sys
import json
import string
import joblib
import numpy as np

# ── Optional NLTK (graceful fallback if network is unavailable) ───────────────
try:
    import nltk
    nltk.download("stopwords", quiet=True)
    nltk.download("punkt",     quiet=True)
    from nltk.corpus import stopwords as _sw
    STOPWORDS = set(_sw.words("english"))
except Exception:
    STOPWORDS = set()

from flask import Flask, render_template, request, jsonify

# ── Paths ────────────────────────────────────────────────────────────────────
BASE_DIR   = os.path.dirname(os.path.abspath(__file__))
MODEL_PATH = os.path.join(BASE_DIR, "model", "saved_model.pkl")
STATS_PATH = os.path.join(BASE_DIR, "model", "model_stats.json")

# ── Load model & stats ───────────────────────────────────────────────────────
pipeline    = None
model_stats = {}

# Auto-bootstrap: if no trained model exists, run the demo model generator
if not os.path.exists(MODEL_PATH):
    print("[INFO] No saved model found. Generating demo model…")
    demo_script = os.path.join(BASE_DIR, "model", "create_demo_model.py")
    if os.path.exists(demo_script):
        import subprocess
        result = subprocess.run(
            [sys.executable, demo_script],
            capture_output=True, text=True
        )
        print(result.stdout)
        if result.returncode != 0:
            print("[WARN] Demo model generation failed:", result.stderr)
    else:
        print("[WARN] create_demo_model.py not found. Train manually.")

if os.path.exists(MODEL_PATH):
    try:
        pipeline = joblib.load(MODEL_PATH)
        print(f"[INFO] Model loaded: {MODEL_PATH}")
    except Exception as e:
        print(f"[WARN] Could not load model: {e}")

if os.path.exists(STATS_PATH):
    with open(STATS_PATH) as f:
        model_stats = json.load(f)

# ── Flask app ────────────────────────────────────────────────────────────────
app = Flask(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# TEXT UTILS
# ─────────────────────────────────────────────────────────────────────────────

def clean_text(text: str) -> str:
    if not isinstance(text, str):
        return ""
    text = text.lower()
    text = re.sub(r"http\S+|www\S+", " ", text)
    text = re.sub(r"<[^>]+>",        " ", text)
    text = re.sub(r"[^a-z\s]",       " ", text)
    text = re.sub(r"\s+",            " ", text).strip()
    tokens = [t for t in text.split() if t not in STOPWORDS and len(t) > 2]
    return " ".join(tokens)


# Suspicious indicator keywords mapped to risk categories
SUSPICIOUS_PATTERNS = {
    "No Experience Required / Easy Money": [
        "no experience", "no experience required", "earn from home",
        "work from home earn", "make money fast", "easy money",
        "unlimited earning", "earn unlimited", "get paid daily",
    ],
    "Vague or Generic Description": [
        "various tasks", "general duties", "miscellaneous", "flexible work",
        "ad posting", "data entry at home", "typing work from home",
    ],
    "Suspicious Contact / Communication": [
        "whatsapp", "telegram", "direct message", "contact us directly",
        "gmail.com", "yahoo.com", "hotmail.com",
    ],
    "Upfront Payment Required": [
        "registration fee", "training fee", "deposit required",
        "pay to apply", "pay to work", "advance payment", "security deposit",
    ],
    "Unrealistic Salary Claims": [
        "earn 50000", "earn 1 lakh", "earn lakhs", "high salary guaranteed",
        "salary negotiable up to", "earn crores", "earn in dollars daily",
    ],
    "Urgency / Pressure Tactics": [
        "apply immediately", "urgent hiring", "limited slots",
        "only few seats", "hurry", "last chance", "apply now before",
    ],
    "Unverifiable Company": [
        "our company", "reputed firm", "mnc company",
        "international company", "global company hiring",
    ],
}


def detect_suspicious_indicators(text: str) -> list[dict]:
    text_lower = text.lower()
    found = []
    for category, patterns in SUSPICIOUS_PATTERNS.items():
        matched = [p for p in patterns if p in text_lower]
        if matched:
            found.append({
                "category": category,
                "matched_phrases": matched[:3],   # cap to 3
            })
    return found


def risk_level(confidence_fake: float) -> str:
    if confidence_fake >= 0.75:
        return "HIGH"
    elif confidence_fake >= 0.45:
        return "MEDIUM"
    return "LOW"


def generate_explanation(prediction: int, confidence: float, indicators: list) -> str:
    if prediction == 1:  # FAKE
        parts = [
            f"This posting shows a {round(confidence * 100, 1)}% probability of being fraudulent."
        ]
        if indicators:
            cats = [i["category"] for i in indicators]
            parts.append(f"Suspicious signals detected: {', '.join(cats[:3])}.")
        parts.append(
            "Exercise extreme caution. Never pay upfront fees, share financial details, "
            "or communicate only through personal messaging apps with recruiters."
        )
    else:  # REAL
        parts = [
            f"This posting appears legitimate with {round(confidence * 100, 1)}% confidence."
        ]
        if indicators:
            parts.append(
                "Minor suspicious signals were noted but did not override the overall assessment. "
                "Still verify the company independently."
            )
        else:
            parts.append(
                "No significant red flags detected. Always verify the company on official sources."
            )
    return " ".join(parts)


# ─────────────────────────────────────────────────────────────────────────────
# PREDICTION PIPELINE
# ─────────────────────────────────────────────────────────────────────────────

def predict_from_text(raw_text: str) -> dict:
    if pipeline is None:
        return {"error": "Model not loaded. Please train the model first using model/train_model.py"}

    cleaned = clean_text(raw_text)
    if not cleaned.strip():
        return {"error": "Could not extract meaningful text from the provided URL."}

    proba      = pipeline.predict_proba([cleaned])[0]
    prediction = int(np.argmax(proba))
    conf_real  = float(proba[0])
    conf_fake  = float(proba[1])

    indicators = detect_suspicious_indicators(raw_text)
    explanation = generate_explanation(prediction, conf_fake if prediction == 1 else conf_real, indicators)

    return {
        "prediction":        "FAKE" if prediction == 1 else "REAL",
        "prediction_label":  "⚠ Fraudulent Job Posting" if prediction == 1 else "✓ Legitimate Job Posting",
        "confidence":        round(conf_fake * 100 if prediction == 1 else conf_real * 100, 2),
        "confidence_real":   round(conf_real * 100, 2),
        "confidence_fake":   round(conf_fake * 100, 2),
        "risk_level":        risk_level(conf_fake),
        "suspicious_indicators": indicators,
        "explanation":       explanation,
    }


# ─────────────────────────────────────────────────────────────────────────────
# ROUTES
# ─────────────────────────────────────────────────────────────────────────────

@app.route("/")
def home():
    return render_template("index.html")


@app.route("/detector")
def detector():
    return render_template("detector.html")


@app.route("/research")
def research():
    return render_template("research.html")


@app.route("/about")
def about():
    stats = model_stats.get("dataset_stats", {})
    return render_template("about.html", stats=stats, model_stats=model_stats)


@app.route("/contact")
def contact():
    return render_template("contact.html")


# ── API: analyse by URL ──────────────────────────────────────────────────────
@app.route("/api/analyze", methods=["POST"])
def analyze():
    from scraper.scraper import scrape_job_posting

    data = request.get_json(silent=True) or {}
    url  = (data.get("url") or "").strip()

    if not url:
        return jsonify({"error": "No URL provided."}), 400

    if not re.match(r"^https?://", url):
        url = "https://" + url

    try:
        scraped = scrape_job_posting(url)
    except Exception as e:
        return jsonify({"error": f"Failed to scrape URL: {str(e)}"}), 422

    raw_text = scraped.get("combined_text", "")
    result   = predict_from_text(raw_text)

    if "error" in result:
        return jsonify(result), 500

    result["scraped"] = {
        "title":        scraped.get("title",       "")[:200],
        "company":      scraped.get("company",     "")[:200],
        "description":  scraped.get("description", "")[:600],
        "salary":       scraped.get("salary",      "")[:200],
        "url":          url,
    }
    return jsonify(result)


# ── API: analyse raw text (demo / fallback) ──────────────────────────────────
@app.route("/api/analyze-text", methods=["POST"])
def analyze_text():
    data     = request.get_json(silent=True) or {}
    raw_text = (data.get("text") or "").strip()

    if not raw_text:
        return jsonify({"error": "No text provided."}), 400

    result = predict_from_text(raw_text)
    if "error" in result:
        return jsonify(result), 500
    return jsonify(result)


# ── API: stats ───────────────────────────────────────────────────────────────
@app.route("/api/stats")
def stats():
    return jsonify(model_stats)


# ── API: health ──────────────────────────────────────────────────────────────
@app.route("/api/health")
def health():
    return jsonify({
        "status":       "ok",
        "model_loaded": pipeline is not None,
        "best_model":   model_stats.get("best_model", "N/A"),
    })


# ─────────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    app.run(debug=True, port=5000)
