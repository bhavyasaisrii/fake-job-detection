# 🔍 Fake Job & Internship Detector

> An AI/ML web application that predicts whether a job or internship posting is **real or fraudulent** by scraping and analyzing the URL of the posting page.

**Research Project**: *"Detecting Fraudulent Online Job and Internship Postings Using Machine Learning and Natural Language Processing"*

**By**: Bhavya Bandarupalli · B.Tech CSE · KLH University (2nd Year)  
**Email**: bandarupallibhavya30@gmail.com  
**LinkedIn**: https://www.linkedin.com/in/bhavya-bandarupalli-a948bb385/

---

## 🏗️ Project Structure

```
fake_job_detector/
├── dataset/
│   └── fake_job_postings.csv       ← Download from Kaggle (see below)
├── model/
│   ├── train_model.py              ← Training script
│   ├── saved_model.pkl             ← Generated after training
│   └── model_stats.json            ← Generated after training
├── scraper/
│   └── scraper.py                  ← Web scraping module
├── templates/
│   ├── base.html                   ← Layout template
│   ├── index.html                  ← Home page
│   ├── detector.html               ← Detector tool page
│   ├── about.html                  ← About/research page
│   └── contact.html                ← Contact page
├── static/
│   ├── css/style.css               ← All styles
│   └── js/main.js                  ← Frontend logic
├── app.py                          ← Flask application
├── requirements.txt                ← Python dependencies
├── render.yaml                     ← Render.com deployment config
└── README.md                       ← This file
```

---

## ⚡ Quick Start

### 1. Clone / Download the project

```bash
git clone https://github.com/YOUR_USERNAME/fake-job-detector.git
cd fake-job-detector
```

### 2. Create a virtual environment

```bash
python -m venv venv
# Windows:
venv\Scripts\activate
# macOS/Linux:
source venv/bin/activate
```

### 3. Install dependencies

```bash
pip install -r requirements.txt
```

### 4. Download the dataset

1. Go to: https://www.kaggle.com/datasets/shivamb/real-or-fake-fake-jobposting-prediction
2. Download `fake_job_postings.csv`
3. Place it in the `dataset/` folder:

```
fake_job_detector/
└── dataset/
    └── fake_job_postings.csv
```

### 5. Train the model

```bash
cd model
python train_model.py
cd ..
```

This will:
- Load and clean the dataset
- Train Logistic Regression, Random Forest, and Naive Bayes models
- Compare accuracy and F1 scores
- Save the best model to `model/saved_model.pkl`
- Save statistics to `model/model_stats.json`

Training takes **2–5 minutes** depending on your hardware.

### 6. Run the Flask server

```bash
python app.py
```

Open your browser at: **http://localhost:5000**

---

## 🔌 API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET  | `/` | Home page |
| GET  | `/detector` | Detector tool |
| GET  | `/about` | About/research page |
| GET  | `/contact` | Contact page |
| POST | `/api/analyze` | Analyze a job posting URL |
| POST | `/api/analyze-text` | Analyze raw job posting text |
| GET  | `/api/stats` | Model & dataset statistics (JSON) |
| GET  | `/api/health` | Health check (JSON) |

### Example: Analyze URL

```bash
curl -X POST http://localhost:5000/api/analyze \
  -H "Content-Type: application/json" \
  -d '{"url": "https://www.indeed.com/viewjob?jk=someJobId"}'
```

### Example: Analyze Text

```bash
curl -X POST http://localhost:5000/api/analyze-text \
  -H "Content-Type: application/json" \
  -d '{"text": "Exciting work from home opportunity! No experience required. Earn $500/day..."}'
```

### Response Format

```json
{
  "prediction": "FAKE",
  "prediction_label": "⚠ Fraudulent Job Posting",
  "confidence": 94.2,
  "confidence_real": 5.8,
  "confidence_fake": 94.2,
  "risk_level": "HIGH",
  "suspicious_indicators": [
    {
      "category": "No Experience Required / Easy Money",
      "matched_phrases": ["no experience required", "earn from home"]
    }
  ],
  "explanation": "This posting shows a 94.2% probability of being fraudulent...",
  "scraped": {
    "title": "Work From Home Data Entry",
    "company": "",
    "description": "...",
    "salary": "$500/day",
    "url": "https://..."
  }
}
```

---

## 🤖 ML Pipeline Details

### Dataset
- **Source**: [Kaggle — Real or Fake: Fake Job Posting Prediction](https://www.kaggle.com/datasets/shivamb/real-or-fake-fake-jobposting-prediction)
- **Size**: ~17,880 samples
- **Labels**: `fraudulent` (0 = real, 1 = fake)
- **Fraud rate**: ~4.84%

### Text Preprocessing
1. Lowercase conversion
2. HTML tag removal
3. URL removal
4. Punctuation stripping (`[^a-z\s]`)
5. NLTK English stopword removal
6. Short token removal (< 3 characters)

### Feature Extraction
- **Method**: TF-IDF Vectorization
- **Max features**: 15,000
- **N-gram range**: (1, 2) — unigrams + bigrams
- **Sublinear TF**: True
- **Min document frequency**: 2

### Models Trained
| Model | Notes |
|-------|-------|
| Logistic Regression | `max_iter=1000`, `class_weight=balanced` |
| Random Forest | `n_estimators=200`, `max_depth=20`, `class_weight=balanced` |
| Naive Bayes | `MultinomialNB(alpha=0.1)` |

The model with the highest accuracy on the 20% test split is automatically selected.

---

## 🚀 Deployment on Render.com (Free)

### Step 1: Push to GitHub

```bash
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/YOUR_USERNAME/fake-job-detector.git
git push -u origin main
```

### Step 2: Train and commit the model

Before deploying, train locally and commit the generated files:
```bash
python model/train_model.py
git add model/saved_model.pkl model/model_stats.json
git commit -m "Add trained model"
git push
```

> ⚠️ `saved_model.pkl` may be large. If >100MB, use [Git LFS](https://git-lfs.github.com/).

### Step 3: Deploy on Render

1. Go to https://render.com and sign up (free)
2. Click **New → Web Service**
3. Connect your GitHub repository
4. Render will auto-detect `render.yaml`
5. Click **Deploy**

Your app will be live at: `https://fake-job-detector.onrender.com`

### render.yaml (included)

```yaml
services:
  - type: web
    name: fake-job-detector
    env: python
    buildCommand: pip install -r requirements.txt
    startCommand: gunicorn app:app
    envVars:
      - key: PYTHON_VERSION
        value: 3.11.0
```

---

## 🔧 Deployment on Vercel (Alternative — Serverless)

Vercel works best for Node.js, but Python Flask can be deployed using the `vercel.json` adapter:

```json
{
  "version": 2,
  "builds": [{ "src": "app.py", "use": "@vercel/python" }],
  "routes": [{ "src": "/(.*)", "dest": "app.py" }]
}
```

> Note: Vercel free tier has a 50MB function size limit. If `saved_model.pkl` is large, use Render instead.

---

## ⚠️ Known Limitations

1. **LinkedIn / login-gated URLs**: LinkedIn redirects scrapers to the login page. Use the **paste text** option instead.
2. **JavaScript-rendered pages**: Some modern sites (React SPAs) render content via JS. BeautifulSoup cannot execute JS. A fallback to raw text input is provided.
3. **Class imbalance**: The dataset is ~95% real, 5% fake. Models use `class_weight='balanced'` to compensate.
4. **Not a guarantee**: Probabilistic model — always verify independently.

---

## 📜 License

MIT License. Free to use with attribution to **Bhavya Bandarupalli**.

---

*Made by Bhavya Bandarupalli · B.Tech CSE Student · KLH University (2nd Year)*
