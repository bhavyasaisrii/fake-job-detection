"""
scraper.py
----------
Scrapes job/internship posting content from a given URL.
Returns a dict with extracted text fields.
"""

import re
import requests
from bs4 import BeautifulSoup

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/124.0.0.0 Safari/537.36"
    ),
    "Accept-Language": "en-US,en;q=0.9",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
}

TIMEOUT = 15  # seconds


# ─────────────────────────────────────────────────────────────────────────────
# HELPERS
# ─────────────────────────────────────────────────────────────────────────────

def _fetch_html(url: str) -> BeautifulSoup | None:
    try:
        resp = requests.get(url, headers=HEADERS, timeout=TIMEOUT)
        resp.raise_for_status()
        return BeautifulSoup(resp.text, "lxml")
    except Exception as e:
        raise RuntimeError(f"Failed to fetch URL: {e}")


def _get_meta(soup: BeautifulSoup, name: str) -> str:
    tag = soup.find("meta", attrs={"name": name}) or \
          soup.find("meta", attrs={"property": name}) or \
          soup.find("meta", attrs={"property": f"og:{name}"})
    if tag:
        return tag.get("content", "").strip()
    return ""


def _clean(text: str) -> str:
    text = re.sub(r"\s+", " ", text)
    return text.strip()


# ─────────────────────────────────────────────────────────────────────────────
# PLATFORM-SPECIFIC EXTRACTORS
# ─────────────────────────────────────────────────────────────────────────────

def _extract_linkedin(soup: BeautifulSoup) -> dict:
    result = {}
    title_tag = soup.find("h1", class_=re.compile("job|title", re.I))
    if title_tag:
        result["title"] = _clean(title_tag.get_text())

    company_tag = soup.find("a", class_=re.compile("company|employer", re.I))
    if company_tag:
        result["company"] = _clean(company_tag.get_text())

    desc_tag = soup.find("div", class_=re.compile("description|details", re.I))
    if desc_tag:
        result["description"] = _clean(desc_tag.get_text(" "))

    return result


def _extract_indeed(soup: BeautifulSoup) -> dict:
    result = {}
    title_tag = soup.find("h1", attrs={"data-testid": re.compile("jobTitle|title", re.I)}) or \
                soup.find("h1", class_=re.compile("jobTitle|title", re.I))
    if title_tag:
        result["title"] = _clean(title_tag.get_text())

    company_tag = soup.find("div", attrs={"data-testid": "inlineHeader-companyName"}) or \
                  soup.find("span", class_=re.compile("company", re.I))
    if company_tag:
        result["company"] = _clean(company_tag.get_text())

    desc_tag = soup.find("div", id=re.compile("jobDescription", re.I)) or \
               soup.find("div", class_=re.compile("jobDescription", re.I))
    if desc_tag:
        result["description"] = _clean(desc_tag.get_text(" "))

    return result


# ─────────────────────────────────────────────────────────────────────────────
# GENERIC EXTRACTOR  (fallback for any site)
# ─────────────────────────────────────────────────────────────────────────────

def _extract_generic(soup: BeautifulSoup) -> dict:
    result = {}

    # Title — prefer <h1>, then <title>, then OG title
    h1 = soup.find("h1")
    result["title"] = _clean(h1.get_text()) if h1 else \
                      (_get_meta(soup, "title") or _clean(soup.title.get_text() if soup.title else ""))

    # Company — look for common patterns
    for sel in [
        {"class": re.compile(r"company|employer|org", re.I)},
        {"itemprop": "hiringOrganization"},
        {"data-testid": re.compile(r"company", re.I)},
    ]:
        tag = soup.find(True, sel)
        if tag:
            result["company"] = _clean(tag.get_text())
            break

    # Description — find the biggest text block related to "job"
    for sel in [
        {"id":    re.compile(r"job.?desc|description|details|posting", re.I)},
        {"class": re.compile(r"job.?desc|description|details|posting|content", re.I)},
        {"itemprop": "description"},
    ]:
        tag = soup.find(True, sel)
        if tag:
            result["description"] = _clean(tag.get_text(" "))
            break

    # Salary
    for sel in [
        {"class": re.compile(r"salary|compensation|pay|wage", re.I)},
        {"id":    re.compile(r"salary|compensation|pay",      re.I)},
    ]:
        tag = soup.find(True, sel)
        if tag:
            result["salary"] = _clean(tag.get_text())
            break

    # Requirements
    for sel in [
        {"class": re.compile(r"require|qualif|skill|eligib", re.I)},
        {"id":    re.compile(r"require|qualif|skill",        re.I)},
    ]:
        tag = soup.find(True, sel)
        if tag:
            result["requirements"] = _clean(tag.get_text(" "))
            break

    # Fallback: grab all visible text from <main> or <article> or <body>
    if not result.get("description"):
        container = soup.find("main") or soup.find("article") or soup.find("body")
        if container:
            # Remove script/style noise
            for tag in container.find_all(["script", "style", "nav", "footer", "header"]):
                tag.decompose()
            result["description"] = _clean(container.get_text(" "))[:5000]

    return result


# ─────────────────────────────────────────────────────────────────────────────
# PUBLIC API
# ─────────────────────────────────────────────────────────────────────────────

def scrape_job_posting(url: str) -> dict:
    """
    Scrape a job/internship posting URL and return extracted fields.

    Returns:
        dict with keys: title, company, description, requirements,
                        salary, combined_text, url
    Raises:
        RuntimeError on fetch failure.
    """
    soup = _fetch_html(url)

    # Route to platform-specific extractor
    if "linkedin.com" in url:
        data = _extract_linkedin(soup)
    elif "indeed.com" in url:
        data = _extract_indeed(soup)
    else:
        data = _extract_generic(soup)

    # Fill missing fields with empty strings
    for key in ["title", "company", "description", "requirements", "salary"]:
        data.setdefault(key, "")

    # Build combined_text for the ML model
    data["combined_text"] = " ".join([
        data["title"],
        data["company"],
        data["description"],
        data["requirements"],
        data["salary"],
    ])
    data["url"] = url
    return data


# ─────────────────────────────────────────────────────────────────────────────
# QUICK TEST
# ─────────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    import sys
    test_url = sys.argv[1] if len(sys.argv) > 1 else "https://www.indeed.com/jobs?q=python+developer"
    result = scrape_job_posting(test_url)
    for k, v in result.items():
        if k != "combined_text":
            print(f"{k:15}: {str(v)[:120]}")
