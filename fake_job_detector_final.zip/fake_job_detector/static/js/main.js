/* ═══════════════════════════════════════════════════
   Fake Job Detector — Main JS
═══════════════════════════════════════════════════ */

// ── Theme toggle ───────────────────────────────────
const themeBtn = document.getElementById('themeBtn');
const root     = document.documentElement;

function applyTheme(t) {
  root.setAttribute('data-theme', t);
  if (themeBtn) themeBtn.textContent = t === 'dark' ? '☀️' : '🌙';
  localStorage.setItem('theme', t);
}

(function initTheme() {
  const saved = localStorage.getItem('theme') || 'dark';
  applyTheme(saved);
})();

if (themeBtn) {
  themeBtn.addEventListener('click', () => {
    const cur = root.getAttribute('data-theme') || 'dark';
    applyTheme(cur === 'dark' ? 'light' : 'dark');
  });
}

// ── Active nav link ────────────────────────────────
document.querySelectorAll('.nav-links a').forEach(link => {
  if (link.href === location.href) link.classList.add('active');
});

// ── Smooth reveal on scroll ────────────────────────
const observer = new IntersectionObserver(
  entries => entries.forEach(e => {
    if (e.isIntersecting) {
      e.target.style.opacity = '1';
      e.target.style.transform = 'translateY(0)';
    }
  }),
  { threshold: 0.1 }
);

document.querySelectorAll('.feature-card, .how-card, .stat-item').forEach(el => {
  el.style.opacity    = '0';
  el.style.transform  = 'translateY(20px)';
  el.style.transition = 'opacity .5s ease, transform .5s ease';
  observer.observe(el);
});


/* ═══════════════════════════════════════════════════
   DETECTOR PAGE LOGIC
═══════════════════════════════════════════════════ */

const urlInput     = document.getElementById('urlInput');
const analyzeBtn   = document.getElementById('analyzeBtn');
const analyzeTextBtn = document.getElementById('analyzeTextBtn');
const textInput    = document.getElementById('textInput');
const loadingCard  = document.getElementById('loadingCard');
const resultCard   = document.getElementById('resultCard');
const errorCard    = document.getElementById('errorCard');

// Step tracker
const steps = [
  'Fetching webpage…',
  'Extracting job details…',
  'Running NLP pipeline…',
  'Computing TF-IDF vectors…',
  'Predicting with ML model…',
];

function animateSteps() {
  const container = document.getElementById('stepsList');
  if (!container) return;
  container.innerHTML = '';
  steps.forEach((s, i) => {
    const div = document.createElement('div');
    div.className = 'step-item';
    div.id = `step-${i}`;
    div.innerHTML = `<span class="step-icon">○</span><span>${s}</span>`;
    container.appendChild(div);
  });

  let idx = 0;
  const interval = setInterval(() => {
    if (idx > 0) {
      const prev = document.getElementById(`step-${idx - 1}`);
      if (prev) { prev.className = 'step-item done'; prev.querySelector('.step-icon').textContent = '✓'; }
    }
    const cur = document.getElementById(`step-${idx}`);
    if (cur) { cur.className = 'step-item active-step'; cur.querySelector('.step-icon').textContent = '▶'; }
    idx++;
    if (idx >= steps.length) clearInterval(interval);
  }, 700);
}

function showLoading() {
  hide(resultCard);
  hide(errorCard);
  show(loadingCard);
  animateSteps();
}

function showError(msg) {
  hide(loadingCard);
  hide(resultCard);
  const ec = show(errorCard);
  document.getElementById('errorMsg').textContent = msg || 'An unexpected error occurred.';
}

function show(el) { if (el) { el.classList.add('active'); } return el; }
function hide(el) { if (el) { el.classList.remove('active'); } }

function renderResult(data) {
  hide(loadingCard);
  hide(errorCard);
  show(resultCard);

  const isFake = data.prediction === 'FAKE';
  const cls    = isFake ? 'fake' : 'real';
  const icon   = isFake ? '⚠️' : '✅';

  // Header
  document.getElementById('resultHeader').className = `result-header ${cls}`;
  document.getElementById('resultIcon').className   = `result-icon ${cls}`;
  document.getElementById('resultIcon').textContent  = icon;
  document.getElementById('resultVerdict').className = `result-verdict ${cls}`;
  document.getElementById('verdictText').textContent = data.prediction_label;
  document.getElementById('verdictSub').textContent  = `Risk Level: ${data.risk_level}`;

  // Risk badge
  const badge = document.getElementById('riskBadge');
  badge.className   = `risk-badge risk-${data.risk_level}`;
  badge.textContent = `${data.risk_level} RISK`;

  // Confidence bars
  const realPct = data.confidence_real;
  const fakePct = data.confidence_fake;

  document.getElementById('realPct').textContent    = `${realPct.toFixed(1)}%`;
  document.getElementById('fakePct').textContent    = `${fakePct.toFixed(1)}%`;
  document.getElementById('realBar').style.width    = '0%';
  document.getElementById('fakeBar').style.width    = '0%';

  setTimeout(() => {
    document.getElementById('realBar').style.width = `${realPct}%`;
    document.getElementById('fakeBar').style.width = `${fakePct}%`;
  }, 100);

  // Indicators
  const indWrap = document.getElementById('indicatorsWrap');
  const indicators = data.suspicious_indicators || [];
  if (indicators.length === 0) {
    indWrap.innerHTML = '<p class="no-indicators">✓ No suspicious patterns detected in this posting.</p>';
  } else {
    indWrap.innerHTML = indicators.map(ind => `
      <div class="indicator-item">
        <div class="indicator-cat">⚑ ${ind.category}</div>
        <div class="indicator-phrases">
          ${(ind.matched_phrases || []).map(p => `<span class="phrase-tag">"${p}"</span>`).join('')}
        </div>
      </div>
    `).join('');
  }

  // Explanation
  document.getElementById('explanationText').textContent = data.explanation || '';

  // Scraped info
  const scraped = data.scraped || {};
  const scrapedWrap = document.getElementById('scrapedWrap');
  const fields = [
    ['Title',   scraped.title],
    ['Company', scraped.company],
    ['Salary',  scraped.salary],
    ['URL',     scraped.url],
  ].filter(([, v]) => v);

  if (fields.length) {
    scrapedWrap.innerHTML = fields.map(([k, v]) => `
      <div class="scraped-field">
        <span class="scraped-key">${k}</span>
        <span class="scraped-val">${v.length > 180 ? v.slice(0, 180) + '…' : v}</span>
      </div>
    `).join('');
  } else {
    scrapedWrap.innerHTML = '<p class="text-sm text-muted">No structured fields extracted.</p>';
  }

  // Scroll to result
  resultCard.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

// ── Analyze by URL ─────────────────────────────────
if (analyzeBtn) {
  analyzeBtn.addEventListener('click', async () => {
    const url = (urlInput?.value || '').trim();
    if (!url) { urlInput?.focus(); return; }

    analyzeBtn.disabled = true;
    analyzeBtn.textContent = 'Analyzing…';
    showLoading();

    try {
      const res  = await fetch('/api/analyze', {
        method:  'POST',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify({ url }),
      });
      const data = await res.json();
      if (!res.ok || data.error) throw new Error(data.error || 'Analysis failed.');
      renderResult(data);
    } catch (err) {
      showError(err.message);
    } finally {
      analyzeBtn.disabled = false;
      analyzeBtn.innerHTML = '<span>🔍</span> Analyze Job Posting';
    }
  });
}

// ── Analyze by raw text ────────────────────────────
if (analyzeTextBtn) {
  analyzeTextBtn.addEventListener('click', async () => {
    const text = (textInput?.value || '').trim();
    if (!text) { textInput?.focus(); return; }

    analyzeTextBtn.disabled = true;
    analyzeTextBtn.textContent = 'Analyzing…';
    showLoading();

    try {
      const res  = await fetch('/api/analyze-text', {
        method:  'POST',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify({ text }),
      });
      const data = await res.json();
      if (!res.ok || data.error) throw new Error(data.error || 'Analysis failed.');
      renderResult(data);
    } catch (err) {
      showError(err.message);
    } finally {
      analyzeTextBtn.disabled = false;
      analyzeTextBtn.innerHTML = '<span>📄</span> Analyze Text';
    }
  });
}

// ── Enter key on URL input ─────────────────────────
if (urlInput) {
  urlInput.addEventListener('keydown', e => {
    if (e.key === 'Enter') analyzeBtn?.click();
  });
}

/* ═══════════════════════════════════════════════════
   ABOUT PAGE  —  load & render stats
═══════════════════════════════════════════════════ */
async function loadStats() {
  const ctr = document.getElementById('statsContainer');
  if (!ctr) return;
  try {
    const res  = await fetch('/api/stats');
    const data = await res.json();
    if (data && data.model_results) renderModelTable(data);
  } catch (_) {}
}

function renderModelTable(data) {
  const tableBody = document.getElementById('modelTableBody');
  if (!tableBody) return;
  const best = data.best_model;
  tableBody.innerHTML = '';

  Object.entries(data.model_results).forEach(([name, info]) => {
    const isBest = name === best;
    const tr = document.createElement('tr');
    if (isBest) tr.className = 'best-row';
    tr.innerHTML = `
      <td>${name}${isBest ? '<span class="best-badge">BEST</span>' : ''}</td>
      <td>${(info.accuracy * 100).toFixed(2)}%</td>
      <td>${(info.f1_score * 100).toFixed(2)}%</td>
      <td>TF-IDF (1-2 grams)</td>
    `;
    tableBody.appendChild(tr);
  });
}

loadStats();

/* ── Mobile menu ────────────────────────────────────────────── */
const menuBtn   = document.getElementById('menuBtn');
const navLinks  = document.getElementById('navLinks');
if (menuBtn && navLinks) {
  menuBtn.addEventListener('click', () => {
    navLinks.classList.toggle('open');
    menuBtn.textContent = navLinks.classList.contains('open') ? '✕' : '☰';
  });
  // close on nav click
  navLinks.querySelectorAll('a').forEach(a => {
    a.addEventListener('click', () => {
      navLinks.classList.remove('open');
      menuBtn.textContent = '☰';
    });
  });
}

/* ── Typing placeholder animation on URL input ─────────────── */
const inputEl = document.getElementById('urlInput');
if (inputEl) {
  const demos = [
    'https://www.linkedin.com/jobs/view/…',
    'https://indeed.com/viewjob?jk=…',
    'https://internshala.com/internship/…',
    'https://careers.company.com/job/…',
  ];
  let di = 0;
  setInterval(() => {
    di = (di + 1) % demos.length;
    inputEl.placeholder = demos[di];
  }, 3000);
}

/* ── Copy citation button (research page) ───────────────────── */
const citBtn = document.getElementById('copyCitation');
if (citBtn) {
  citBtn.addEventListener('click', () => {
    const text = document.querySelector('.citation-text')?.textContent || '';
    navigator.clipboard.writeText(text).then(() => {
      citBtn.textContent = '✓ Copied!';
      setTimeout(() => { citBtn.textContent = '📋 Copy Citation'; }, 2000);
    });
  });
}
