# Dataset Folder

Place `fake_job_postings.csv` here before running `model/train_model.py`.

## Download Instructions

1. Go to: https://www.kaggle.com/datasets/shivamb/real-or-fake-fake-jobposting-prediction
2. Sign in to Kaggle (free account)
3. Click **Download** → `archive.zip`
4. Extract and place `fake_job_postings.csv` in this folder

## File Info

| Property      | Value |
|--------------|-------|
| Filename     | `fake_job_postings.csv` |
| Size         | ~4 MB |
| Rows         | 17,880 |
| Target column| `fraudulent` (0 = real, 1 = fake) |
| Key columns  | `title`, `company_profile`, `description`, `requirements`, `benefits` |

## Without the Dataset

If you don't have the dataset, run the demo model generator:

```bash
python model/create_demo_model.py
```

This creates a lightweight demo model trained on synthetic data so the app
works immediately. Accuracy will be lower than the full model.
