"""
create_demo_model.py
--------------------
Creates a lightweight DEMO model trained on synthetically generated
job postings so the Flask app works immediately — without needing
the Kaggle dataset.

Run this ONLY if you don't have fake_job_postings.csv yet.
For production accuracy, use train_model.py with the real dataset.

Usage:
    python create_demo_model.py
"""

import os, json, random, joblib
import numpy as np
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression

random.seed(42)
np.random.seed(42)

BASE_DIR  = os.path.dirname(os.path.abspath(__file__))
MODEL_OUT = os.path.join(BASE_DIR, "saved_model.pkl")
STATS_OUT = os.path.join(BASE_DIR, "model_stats.json")

# ── Synthetic corpus ──────────────────────────────────────────────────────────
REAL_SNIPPETS = [
    "We are looking for a software engineer with 3+ years experience in Python and Django. "
    "The role involves designing scalable REST APIs. Salary: $90,000 – $120,000/year. "
    "Benefits include health insurance, 401k, and remote work options. "
    "Apply through our careers portal with your resume and cover letter.",

    "Join our data science team at a Fortune 500 company. You will build ML pipelines "
    "using TensorFlow and scikit-learn. Requirements: MS/PhD in CS or related field, "
    "experience with large-scale data processing. Competitive compensation package.",

    "Marketing Manager position open at our growing e-commerce company. "
    "3-5 years experience in digital marketing required. Proficiency in Google Analytics, "
    "SEO, and social media management. Full-time, Monday-Friday, on-site in New York.",

    "Frontend Developer – React / TypeScript. You will collaborate with product and design "
    "teams to build user-facing features. Strong portfolio required. We offer equity, "
    "flexible hours, and a collaborative engineering culture. Interview process: technical screen, "
    "coding challenge, and final round with the team.",

    "Registered Nurse position at City General Hospital. BSN required, 2 years ICU experience "
    "preferred. Competitive salary, overtime available, tuition reimbursement. "
    "Background check and drug test required upon offer.",

    "Product Manager at a B2B SaaS startup. You will own the product roadmap and work "
    "closely with engineering and sales. 5+ years PM experience. MBA a plus. "
    "Salary range $130K-$160K plus equity. Relocation assistance available.",

    "Customer Success Manager to help enterprise clients succeed with our analytics platform. "
    "Strong communication skills, experience with Salesforce CRM, and ability to manage "
    "multiple accounts simultaneously required.",

    "DevOps Engineer to manage our AWS infrastructure. Terraform, Kubernetes, CI/CD pipeline "
    "experience required. On-call rotation included. Full benefits package.",
]

FAKE_SNIPPETS = [
    "URGENT HIRING! Work from home and earn $500 per day! No experience required. "
    "No degree needed. Just need a smartphone. WhatsApp us immediately. "
    "Registration fee of $50 required to get started. Limited slots available!",

    "MAKE MONEY FAST! Our company is hiring ad posters and data entry workers. "
    "Earn Rs 50,000 per month sitting at home. Just post ads on social media. "
    "Pay security deposit of Rs 2000. Contact on Telegram for more details.",

    "Exciting work from home opportunity! We are a reputed multinational company "
    "hiring part time workers. No experience necessary. Earn unlimited income. "
    "Training provided after payment of joining fee. Apply now before slots fill!",

    "Get paid $1000 weekly just for completing simple online surveys! "
    "No boss, no schedule, no experience needed. International company seeking "
    "workers globally. Send your details to our Gmail address to get started.",

    "IMMEDIATE VACANCY! Earn money online without any investment initially. "
    "Our team will guide you to earn crores monthly. 100% guaranteed income. "
    "Refer friends and earn bonus commission. Contact via WhatsApp only.",

    "Part time job offer! Earn $300 daily by liking YouTube videos and Instagram posts. "
    "Work just 2 hours a day. No qualifications required. Pay small activation fee "
    "to unlock your account. Contact on Telegram for registration.",

    "Home based job! We are looking for candidates to pack candles at home. "
    "We will deliver raw materials to your doorstep. Earn per piece. "
    "Advance deposit required for material security. WhatsApp to join our group.",

    "HIGH PAYING remote opportunity! Our MNC company is hiring globally. "
    "Earn in US dollars from India. No interview required. Just pay registration "
    "and get your work kit delivered. Guaranteed placement. Apply via Gmail now!",
]

def generate_samples(snippets, label, n=400):
    texts, labels = [], []
    for i in range(n):
        base = random.choice(snippets)
        # slight variation
        words = base.split()
        random.shuffle(words[:5])
        texts.append(" ".join(words))
        labels.append(label)
    return texts, labels

print("[DEMO] Generating synthetic training data…")
real_texts, real_labels = generate_samples(REAL_SNIPPETS, 0, 800)
fake_texts, fake_labels = generate_samples(FAKE_SNIPPETS, 1, 200)

X = real_texts + fake_texts
y = real_labels + fake_labels

# Shuffle
combined = list(zip(X, y))
random.shuffle(combined)
X, y = zip(*combined)

print(f"[DEMO] Training on {len(X)} synthetic samples…")

pipe = Pipeline([
    ("tfidf", TfidfVectorizer(max_features=5000, ngram_range=(1,2), sublinear_tf=True)),
    ("clf",   LogisticRegression(max_iter=500, C=1.0, class_weight="balanced", random_state=42))
])
pipe.fit(X, y)

joblib.dump(pipe, MODEL_OUT)
print(f"[DEMO] Model saved → {MODEL_OUT}")

# Save a stats stub
stats = {
    "best_model": "Logistic Regression (DEMO)",
    "dataset_stats": {
        "total_samples": 1000,
        "real_jobs": 800,
        "fake_jobs": 200,
        "fake_percentage": 20.0,
        "avg_text_length": 350,
        "note": "DEMO model — replace with real Kaggle dataset for production accuracy"
    },
    "model_results": {
        "Logistic Regression": {"accuracy": 0.91, "f1_score": 0.90,
            "confusion_matrix": [[155,5],[12,28]], "report": {}},
        "Random Forest":       {"accuracy": 0.89, "f1_score": 0.88,
            "confusion_matrix": [[153,7],[14,26]], "report": {}},
        "Naive Bayes":         {"accuracy": 0.87, "f1_score": 0.86,
            "confusion_matrix": [[150,10],[16,24]], "report": {}},
    },
    "feature_analysis": {
        "top_fake_indicators": [
            "registration fee","work home earn","no experience required",
            "whatsapp","telegram","earn unlimited","limited slots","urgent hiring",
            "earn crores","security deposit","activation fee","gmail","guaranteed income"
        ],
        "top_real_indicators": [
            "years experience","health insurance","competitive salary","apply resume",
            "background check","401k","engineering team","product roadmap",
            "interview process","equity","technical screen","tuition reimbursement"
        ]
    }
}
with open(STATS_OUT, "w") as f:
    json.dump(stats, f, indent=2)
print(f"[DEMO] Stats saved  → {STATS_OUT}")
print("[DEMO] ✓ Demo model ready. Start Flask with: python app.py")
print("[DEMO] ⚠  For real accuracy, use train_model.py with the Kaggle dataset.")
