"""
train_model.py
--------------
Trains multiple ML models on the Fake Job Postings dataset,
compares accuracy, and saves the best model + vectorizer.

Dataset: https://www.kaggle.com/datasets/shivamb/real-or-fake-fake-jobposting-prediction
Place fake_job_postings.csv inside the ../dataset/ folder before running.

Usage:
    python train_model.py
"""

import os
import re
import string
import json
import warnings
import pandas as pd
import numpy as np
import joblib
import nltk

from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import (
    accuracy_score, classification_report,
    confusion_matrix, f1_score
)
from sklearn.pipeline import Pipeline

warnings.filterwarnings("ignore")

# ── NLTK downloads ──────────────────────────────────────────────────────────
nltk.download("stopwords", quiet=True)
nltk.download("punkt", quiet=True)
from nltk.corpus import stopwords

STOPWORDS = set(stopwords.words("english"))

# ── Paths ────────────────────────────────────────────────────────────────────
BASE_DIR   = os.path.dirname(os.path.abspath(__file__))
DATASET    = os.path.join(BASE_DIR, "..", "dataset", "fake_job_postings.csv")
MODEL_OUT  = os.path.join(BASE_DIR, "saved_model.pkl")
STATS_OUT  = os.path.join(BASE_DIR, "model_stats.json")

# ─────────────────────────────────────────────────────────────────────────────
# 1. TEXT PREPROCESSING
# ─────────────────────────────────────────────────────────────────────────────

def clean_text(text: str) -> str:
    if not isinstance(text, str):
        return ""
    text = text.lower()
    text = re.sub(r"http\S+|www\S+", " ", text)          # remove URLs
    text = re.sub(r"<[^>]+>", " ", text)                  # strip HTML tags
    text = re.sub(r"[^a-z\s]", " ", text)                 # keep only letters
    text = re.sub(r"\s+", " ", text).strip()
    tokens = text.split()
    tokens = [t for t in tokens if t not in STOPWORDS and len(t) > 2]
    return " ".join(tokens)


# ─────────────────────────────────────────────────────────────────────────────
# 2. LOAD & PREPARE DATA
# ─────────────────────────────────────────────────────────────────────────────

def load_data(path: str) -> pd.DataFrame:
    print(f"[INFO] Loading dataset from {path} …")
    df = pd.read_csv(path)
    print(f"[INFO] Raw shape: {df.shape}")

    # Combine relevant text columns
    text_cols = ["title", "company_profile", "description", "requirements", "benefits"]
    for col in text_cols:
        if col not in df.columns:
            df[col] = ""
    df["combined_text"] = df[text_cols].fillna("").agg(" ".join, axis=1)

    # Target column: fraudulent (0 = real, 1 = fake)
    df = df[["combined_text", "fraudulent"]].dropna()
    df = df[df["combined_text"].str.strip() != ""]
    print(f"[INFO] After cleaning: {df.shape}")
    print(f"[INFO] Class distribution:\n{df['fraudulent'].value_counts()}")
    return df


# ─────────────────────────────────────────────────────────────────────────────
# 3. TRAIN & EVALUATE
# ─────────────────────────────────────────────────────────────────────────────

def build_pipeline(clf):
    return Pipeline([
        ("tfidf", TfidfVectorizer(
            max_features=15000,
            ngram_range=(1, 2),
            sublinear_tf=True,
            min_df=2
        )),
        ("clf", clf)
    ])


def train_and_evaluate(df: pd.DataFrame):
    print("\n[INFO] Preprocessing text …")
    df["clean_text"] = df["combined_text"].apply(clean_text)
    df = df[df["clean_text"].str.strip() != ""]

    X = df["clean_text"]
    y = df["fraudulent"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )
    print(f"[INFO] Train: {len(X_train)} | Test: {len(X_test)}")

    models = {
        "Logistic Regression": LogisticRegression(
            max_iter=1000, C=1.0, class_weight="balanced", random_state=42
        ),
        "Random Forest": RandomForestClassifier(
            n_estimators=200, max_depth=20, class_weight="balanced",
            n_jobs=-1, random_state=42
        ),
        "Naive Bayes": MultinomialNB(alpha=0.1),
    }

    results = {}
    best_name, best_pipe, best_acc = None, None, -1

    for name, clf in models.items():
        print(f"\n[TRAIN] {name} …")
        pipe = build_pipeline(clf)
        pipe.fit(X_train, y_train)
        y_pred = pipe.predict(X_test)

        acc = accuracy_score(y_test, y_pred)
        f1  = f1_score(y_test, y_pred, average="weighted")
        cm  = confusion_matrix(y_test, y_pred).tolist()
        report = classification_report(y_test, y_pred, output_dict=True)

        print(f"  Accuracy : {acc:.4f}")
        print(f"  F1 Score : {f1:.4f}")
        print(classification_report(y_test, y_pred))

        results[name] = {
            "accuracy": round(acc, 4),
            "f1_score": round(f1, 4),
            "confusion_matrix": cm,
            "report": report
        }

        if acc > best_acc:
            best_acc  = acc
            best_name = name
            best_pipe = pipe

    print(f"\n[BEST] {best_name} — Accuracy: {best_acc:.4f}")
    return best_name, best_pipe, results, X_train, X_test, y_train, y_test


# ─────────────────────────────────────────────────────────────────────────────
# 4. FEATURE IMPORTANCE (Logistic Regression coefficients)
# ─────────────────────────────────────────────────────────────────────────────

def get_top_features(pipeline, n=20):
    try:
        vectorizer = pipeline.named_steps["tfidf"]
        clf        = pipeline.named_steps["clf"]
        feature_names = vectorizer.get_feature_names_out()

        if hasattr(clf, "coef_"):
            coef = clf.coef_[0]
            top_fake = [
                feature_names[i]
                for i in np.argsort(coef)[::-1][:n]
            ]
            top_real = [
                feature_names[i]
                for i in np.argsort(coef)[:n]
            ]
            return {"top_fake_indicators": top_fake, "top_real_indicators": top_real}
        elif hasattr(clf, "feature_importances_"):
            top = [
                feature_names[i]
                for i in np.argsort(clf.feature_importances_)[::-1][:n]
            ]
            return {"top_features": top}
    except Exception:
        pass
    return {}


# ─────────────────────────────────────────────────────────────────────────────
# 5. DATASET STATISTICS
# ─────────────────────────────────────────────────────────────────────────────

def dataset_stats(df: pd.DataFrame) -> dict:
    total   = len(df)
    fake    = int(df["fraudulent"].sum())
    real    = total - fake
    avg_len = int(df["combined_text"].str.len().mean())
    return {
        "total_samples": total,
        "real_jobs": real,
        "fake_jobs": fake,
        "fake_percentage": round(fake / total * 100, 2),
        "avg_text_length": avg_len
    }


# ─────────────────────────────────────────────────────────────────────────────
# 6. MAIN
# ─────────────────────────────────────────────────────────────────────────────

def main():
    if not os.path.exists(DATASET):
        print(f"[ERROR] Dataset not found at {DATASET}")
        print("  Download from: https://www.kaggle.com/datasets/shivamb/real-or-fake-fake-jobposting-prediction")
        print("  Then place fake_job_postings.csv in the dataset/ folder.")
        raise SystemExit(1)

    df = load_data(DATASET)
    stats = dataset_stats(df)

    best_name, best_pipe, results, X_train, X_test, y_train, y_test = train_and_evaluate(df)

    features = get_top_features(best_pipe)

    # Save model
    joblib.dump(best_pipe, MODEL_OUT)
    print(f"\n[SAVED] Model → {MODEL_OUT}")

    # Save stats JSON (used by Flask API)
    all_stats = {
        "best_model": best_name,
        "dataset_stats": stats,
        "model_results": results,
        "feature_analysis": features
    }
    with open(STATS_OUT, "w") as f:
        json.dump(all_stats, f, indent=2)
    print(f"[SAVED] Stats → {STATS_OUT}")


if __name__ == "__main__":
    main()
